#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "header.h"

/*r*/
bool allocate10Bytes(uint8_t *outPtr )
{
    const size_t N = 10; /*10 Bytes*/
    uint8_t **p2p = (uint8_t**)outPtr; /*p2p is pointer to pointer to value of type uint8_t*/
    *p2p = (uint8_t*)malloc( N*sizeof( uint8_t ) ); /* datatypes is 1 byte --> 10*1 byte = 10 bytes */
    return *p2p != NULL; /* memory has been allocated to the pointer then this function will return TRUE */
}

void freeMemory(bool check, uint8_t *p)
{
    if ( check == true )
    {
        printf("\n\tallocate successful then free malloc\n");
        printf("\taddress &p =%d\n",&p);
        printf("\tvalue p = %d\n", p); /*Trash value because this pointer didn't point to anywhere*/
        free( p );
    }
    else
    {
    	printf("\tallocate fail");
	}
}
