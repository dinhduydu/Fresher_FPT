#ifndef HEADER_H_
#define HEADER_H_
#include <stdbool.h>
#include <stdint.h>
/**************************************
*Prototype
**************************************/

/**
 * @brief Function to allocate 10 Bytes (memory) for a pointer.
 * return bool: true if allocate successful and fail if allocate fail
 */
bool allocate10Bytes(uint8_t *outPtr );

/**
 * @brief Function used to free memory 
 */
void freeMemory(bool check, uint8_t *p);
#endif/*HEADER_H*/
