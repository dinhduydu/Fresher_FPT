#include "header.h"

/******************************************************************************************
 * Function
 *****************************************************************************************/

/* Run this program using the console pauser or add your own getch, system("pause") or input loop */
void main(void)
{
    uint8_t Array[MAX_ELEMENT]; /* Declare an array to store that elements */
    uint8_t n = 0; /* variable which stores the number of elements of the array*/
    Menu_Option(Array, n);
}
